package org.example.backend.entities;

public enum ReservationStatus { PENDING, CONFIRMED, CANCELLED }
