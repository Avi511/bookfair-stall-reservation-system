package org.example.backend.entities;

public enum EventStatus {
    DRAFT,
    ACTIVE,
    INACTIVE,
    ENDED
}
