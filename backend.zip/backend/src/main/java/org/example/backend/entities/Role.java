package org.example.backend.entities;

public enum Role{
    USER,
    EMPLOYEE
}

